// IIFE (Immediately Invoked Function Expression) để tránh làm ô nhiễm phạm vi toàn cục
(function() {
    // Sử dụng thư viện arrive.js để giám sát các iframe mới
    document.arrive("iframe", function() {
        modifyIframe();
    });

    // Hàm thay đổi src của iframe
    function modifyIframe() {
        document.querySelectorAll('iframe').forEach(iframe => {
            let src = iframe.getAttribute('src');
            if (src && src.includes('tgWebAppPlatform=web')) {
                // Sử dụng biểu thức chính quy để thay thế tất cả các biến thể của 'tgWebAppPlatform=web'
                src = src.replace(/tgWebAppPlatform=web[a-z]?/, 'tgWebAppPlatform=ios');
                iframe.setAttribute('src', src);

                // Gọi hàm thay đổi tiêu đề trang tạm thời
                changeTitleTemporarily();
            }
        });
    }

    // Chạy hàm để thay đổi các iframe tồn tại ngay khi script được nạp
    modifyIframe();

    // Hàm thay đổi tiêu đề trang tạm thời
    function changeTitleTemporarily() {
        const originalTitle = document.title;
        document.title = "Telegram đã được bypass";
        setTimeout(() => {
            document.title = originalTitle;
        }, 10000); // Sau 10 giây, tiêu đề sẽ trở lại ban đầu
    }
})();
